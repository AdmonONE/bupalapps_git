<?php $__env->startSection('content'); ?>

<div class="row">
	<div clss="col-lg-12">
		<ol class="breadcrumb">
			<li class="active">Navegación: Home</li>
			<li><a href="<?php echo e(url('events')); ?>">Mostrar Eventos</a></li>
			<li><a href="<?php echo e(url('events/create')); ?>">Agregar nuevo evento</a></li>
		</ol>
	</div>
</div>

<div class="row">
	<div class="col-lg-12">
		<div id='calendar'></div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('_asset/fullcalendar')); ?>/fullcalendar.min.js"></script>
<script src="<?php echo e(url('_asset/fullcalendar')); ?>/lang/es.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		
		var base_url = '<?php echo e(url('/')); ?>';

		$('#calendar').fullCalendar({
			weekends: true,
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},
			editable: false,
			eventLimit: true, // allow "more" link when too many events
			events: {
				url: base_url + '/api',
				error: function() {
					alert("cannot load json");
				}
			}
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>