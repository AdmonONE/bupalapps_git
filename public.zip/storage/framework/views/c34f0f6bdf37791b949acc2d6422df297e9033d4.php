<?php $__env->startSection('content'); ?>

<h2 style="margin-top: 12%; text-align: center;">Registro de Oficios</h2>

<!--<?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <h2></h2><a href="/registros/<?php echo e($registro->id); ?>"><?php echo e($registro->numero); ?></a></h2>

    <?php echo e(date('F d, Y', strtotime($registro->created_at))); ?>

    
    <p><?php echo e($registro->fecha); ?></p>
    <p><?php echo e($registro->area); ?></p>
    <p><?php echo e($registro->destinatario); ?></p>
    <p><?php echo e($registro->asunto); ?></p>
    <h2><a href="/registros/<?php echo e($registro->id); ?>/edit">Editar Registro</a></h2><br>
    <form class="" action="/registros/<?php echo e($registro->id); ?>" method="post">
        <input type="hidden" name="_method" value="delete">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input class="btn btn-primary" type="submit" name="" value="Eliminar">
    </form>

    <hr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
<hr>






<table class="table" style="background-color: white;">
    <thead>
        <tr style="font-size: 16px">
            <th><strong>Numero</th>
            <th><strong>Fecha</strong></th>
            <th><strong>Area</strong></th>
            <th><strong>Destinatario</strong></th>
            <th><strong>Asunto</strong></th>
          <!--  <th>Acciones</th>-->
        </tr>
    </thead>
<?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td>
    <a href="salud/<?php echo e($registro->id); ?>" class="btn btn-primary"><?php echo e($registro->numero); ?></a>
    </td>
    
    
    <td><?php echo e($registro->fecha); ?></td>
    <td><?php echo e($registro->area); ?></td>
    <td><?php echo e($registro->destinatario); ?></td>
    <td><?php echo e($registro->asunto); ?></td>
    <!--<td><a href="/home/<?php echo e($registro->id); ?>/edit" class="btn btn-success">Editar Registro</a>
    <form class="" action="/home/<?php echo e($registro->id); ?>" method="post">
        <input type="hidden" name="_method" value="delete">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input class="btn btn-primary" type="submit" name="" value="Eliminar">
    </form>
    </td>-->

    
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>