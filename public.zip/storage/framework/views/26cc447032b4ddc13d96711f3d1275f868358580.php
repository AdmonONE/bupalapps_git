<?php $__env->startSection('content'); ?>


<br>
<br>
<br>
<br>
<br>


        <?php echo e(Form::open(['route' => 'eventos.store', 'method' => 'post', 'role' => 'form'])); ?>

        <div id="" class="" tabindex="-1">
            <div class="modal-dialog">

                <div class="content" style="background-color: white; opacity: 0.7;">
                        
                    
                    <div class="modal-header">
                        <h4>Registrar Nuevo Evento</h4>
                    </div>

                    <div class="modal-body">
                        <div class="form-group">
                            <?php echo e(Form::label('date_start', 'Evento')); ?>

                            <?php echo e(Form::text('title', old('date_start'), ['class' => 'form-control'])); ?>

                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('time_start', 'Descripción')); ?>

                            <?php echo e(Form::text('actividades', old('time_start'), ['class' => 'form-control'])); ?>

                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('date_end', 'Fecha')); ?>

                            <?php echo e(Form::text('start', old('date_end'), ['class' => 'form-control'])); ?>

                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('color', 'Color')); ?>

                            <?php echo e(Form::text('date_start', old('date_start'), ['class' => 'form-control'])); ?>

                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dissmiss="">Cancelar</button>
                        <?php echo Form::submit('Guardar', ['class' => 'btn btn-success']); ?>

                    </div>
                </div>
            </div>
            

        </div>
        <?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>