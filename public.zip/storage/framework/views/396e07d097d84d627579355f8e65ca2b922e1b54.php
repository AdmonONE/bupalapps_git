<?php $__env->startSection('content'); ?>

<div id="slider">

		<div class="container contslider">
			<div class="my-slider">
				<ul>
				<?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<li style="background: url(public/img_slideshow/<?php echo e($slider->name); ?>) center"><i><?php echo e($slider->texto); ?></i></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<?php endif; ?>	
					
				</ul>
			</div>
		</div>
		
	</div>
       
<?php $__env->stopSection(); ?>

<?php $__env->startSection('fullcalendar'); ?>

	<div class="container">

		<div id="calendar"></div>	
	</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>