<?php $__env->startSection('content'); ?>

<div class="row">
	<div clss="col-lg-12">
		<ol class="breadcrumb">
			<li>Navegación: <a href="<?php echo e(url('/')); ?>">Home</a></li>
			<li><a href="<?php echo e(url('/events')); ?>">Eventos</a></li>
			<li class="active">Agregar Nuevo Evento</li>
		</ol>
	</div>
</div>

<?php echo $__env->make('message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row">
	<div class="col-lg-6">
		
		<form action="<?php echo e(url('events')); ?>" method="POST">
			<?php echo e(csrf_field()); ?>

			<div class="form-group <?php if($errors->has('name')): ?> has-error has-feedback <?php endif; ?>">
				<label for="name">Responsable del Evento</label>
				<input type="text" class="form-control" name="name" placeholder="Nombre Completo" value="<?php echo e(old('name')); ?>">
				<?php if($errors->has('name')): ?>
					<p class="help-block"><span class="glyphicon glyphicon-exclamation-sign"></span> 
					<?php echo e($errors->first('name')); ?>

					</p>
				<?php endif; ?>
			</div>
			<div class="form-group <?php if($errors->has('title')): ?> has-error has-feedback <?php endif; ?>">
				<label for="title">Evento</label>
				<input type="text" class="form-control" name="title" placeholder="Nombre de la Actividad" value="<?php echo e(old('title')); ?>">
				<?php if($errors->has('title')): ?>
					<p class="help-block"><span class="glyphicon glyphicon-exclamation-sign"></span> 
					<?php echo e($errors->first('title')); ?>

					</p>
				<?php endif; ?>
			</div>
			<div class="form-group <?php if($errors->has('time')): ?> has-error <?php endif; ?>">
				<label for="time">Fecha y Hora de realización</label>
				<div class="input-group">
					<input type="text" class="form-control" name="time" placeholder="Select your time" value="<?php echo e(old('time')); ?>">
					<span class="input-group-addon">
						<span class="glyphicon glyphicon-calendar"></span>
                    </span>
				</div>
				<?php if($errors->has('time')): ?>
					<p class="help-block"><span class="glyphicon glyphicon-exclamation-sign"></span> 
					<?php echo e($errors->first('time')); ?>

					</p>
				<?php endif; ?>
			</div>
			<button type="submit" class="btn btn-primary">Registrar</button>
		</form>		
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('_asset/js')); ?>/daterangepicker.js"></script>
<script type="text/javascript">

$(function () {
	$('input[name="time"]').daterangepicker({
		"minDate": moment('<?php echo date('Y-m-d G')?>'),
		"timePicker": true,
		"timePicker24Hour": true,
		"timePickerIncrement": 15,
		"autoApply": true,
		"locale": {
			"format": "DD/MM/YYYY HH:mm:ss",
			"separator": " - ",
			"daysOfWeek": [
            "Dom",
            "Lun",
            "Mar",
            "Mie",
            "Jue",
            "Vie",
            "Sab"
        ],
        "monthNames": [
            "Enero",
            "Febrero",
            "Marzo",
            "Abril",
            "Mayo",
            "Junio",
            "Julio",
            "Agosto",
            "Septiembre",
            "Octubre",
            "Noviembre",
            "Diciembre"
        ],
        "firstDay": 1
		}
	});
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>