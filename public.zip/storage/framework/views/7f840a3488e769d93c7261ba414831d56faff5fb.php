<?php $__env->startSection('content'); ?>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div style="border-color: white; border-style: solid; background-color: white; width: 100px; float: left;">
    <?php echo e($evento->start); ?>


</div>

    <div style="background-color: red; width: 200px; float: left;">
        <p><?php echo e($evento->title); ?></p>
        <p><?php echo e($evento->actividades); ?></p>
    </div>
    
    <br>
    <br>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>














<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>