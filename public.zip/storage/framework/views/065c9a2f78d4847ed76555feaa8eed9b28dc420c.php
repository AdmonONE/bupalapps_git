<?php $__env->startSection('content'); ?>





                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar-->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>


                    <!--Logout-->
                    <!-- Right Side Of Navbar
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links
                        <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                    -->
                </div>


    <!--  wrapper -->
    <div class="wrapper col-md-8" style="margin-left: 10%; width: 150%;">

    <br>
    








    <div style="">
        

<div id="comslider_in_point_1314348" style="margin-top: 8%;"></div><script type="text/javascript">var oCOMScript1314348=document.createElement('script');oCOMScript1314348.src="http://commondatastorage.googleapis.com/comslider/target/users/1495353673x7c658c33d4d5cc619d7c64aa11804ab8/comslider.js?timestamp=1495354701";oCOMScript1314348.type='text/javascript';document.getElementsByTagName("head").item(0).appendChild(oCOMScript1314348);</script>



<!--<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2Fimderpalmiraoficial%2Fvideos%2F838041146354395%2F&show_text=1&width=560" width="560" height="491" style="border:none;overflow:hidden; background-color: white; margin-top: 5%; width: 50%;" scrolling="no" frameborder="0" allowTransparency="true"></iframe>-->

<!--
<div id="overlay" style="visibility: hidden; width: 20%; position: relative;">
 <div> 
    <object type="text/html" data="http://mailchi.mp/95489a946800/la-un-sede-palmira-presenta-primera-escuela-agrobiolgica?e=2e2b625246" width="800px" height="600px" style="overflow:auto;border:5px ridge blue">
    </object>
 </div>
</div>



<a href='#' onclick='overlay()'>Click here to show the overlay</a>
-->

<!--        <a href="javascript:void(0)" id="loadPage">Click To Load Web Page</a><br />
        <div id="pagecontainer" />-->




    </div>
    <!-- end wrapper -->















<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>