<?php $__env->startSection('content'); ?>





                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar-->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>


                    <!--Logout-->
                    <!-- Right Side Of Navbar
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links
                        <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                    -->
                </div>


    <!--  wrapper -->
    <div class="wrapper col-md-8" style="margin-left: 10%; width: 150%;">

    <br>
    








    <div style="">
        

<!--<div id="comslider_in_point_1314348"></div><script type="text/javascript">var oCOMScript1314348=document.createElement('script');oCOMScript1314348.src="http://commondatastorage.googleapis.com/comslider/target/users/1495353673x7c658c33d4d5cc619d7c64aa11804ab8/comslider.js?timestamp=1495354701";oCOMScript1314348.type='text/javascript';document.getElementsByTagName("head").item(0).appendChild(oCOMScript1314348);</script>-->

<script>

	$(document).ready(function() {
		
		$('#calendar').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,basicWeek,basicDay'
			},
			defaultDate: '2017-04-12',
			navLinks: true, // can click day/week names to navigate views
			editable: true,
			eventLimit: true, // allow "more" link when too many events
			events: [
				{
					title: 'All Day Event',
					start: '2017-04-01'
				},
				{
					title: 'Long Event',
					start: '2017-04-07',
					end: '2017-04-10'
				},
				{
					id: 999,
					title: 'Repeating Event',
					start: '2017-04-09T16:00:00'
				},
				{
					id: 999,
					title: 'Repeating Event',
					start: '2017-04-16T16:00:00'
				},
				{
					title: 'Conference',
					start: '2017-04-11',
					end: '2017-04-13'
				},
				{
					title: 'Meeting',
					start: '2017-04-12T10:30:00',
					end: '2017-04-12T12:30:00'
				},
				{
					title: 'Lunch',
					start: '2017-04-12T12:00:00'
				},
				{
					title: 'Meeting',
					start: '2017-04-12T14:30:00'
				},
				{
					title: 'Happy Hour',
					start: '2017-04-12T17:30:00'
				},
				{
					title: 'Dinner',
					start: '2017-04-12T20:00:00'
				},
				{
					title: 'Birthday Party',
					start: '2017-04-13T07:00:00'
				},
				{
					title: 'Click for Google',
					url: 'http://google.com/',
					start: '2017-04-28'
				}
			]
		});
		
	});

</script>

<div id='calendar'></div>


	</div>



</div>



<!--
<div id="overlay" style="visibility: hidden; width: 20%; position: relative;">
 <div> 
    <object type="text/html" data="http://mailchi.mp/95489a946800/la-un-sede-palmira-presenta-primera-escuela-agrobiolgica?e=2e2b625246" width="800px" height="600px" style="overflow:auto;border:5px ridge blue">
    </object>
 </div>
</div>



<a href='#' onclick='overlay()'>Click here to show the overlay</a>
-->

<!--        <a href="javascript:void(0)" id="loadPage">Click To Load Web Page</a><br />
        <div id="pagecontainer" />-->




    </div>
    <!-- end wrapper -->















<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>