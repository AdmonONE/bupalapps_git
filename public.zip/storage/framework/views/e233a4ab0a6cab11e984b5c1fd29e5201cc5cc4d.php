<?php $__env->startSection('content'); ?>



                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar-->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>


                    <!--Logout-->
                    <!-- Right Side Of Navbar
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links
                        <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                    -->
                </div>


    <!--  wrapper -->
    <div class="wrapper col-md-12">



                            <!-- user image section-->
                        <div class="user-section col-md-3">
                            <div class="user-section-inner">
                                <img src="<?php echo e(Auth::user()->avatar); ?>" alt="">

                            </div>
 
                            <div class="user-info">
                                <div><strong><?php echo e(Auth::user()->name); ?></strong></div>


                                                           <div>
                                <form id="" action="<?php echo e(route('logout')); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <button class="btn btn-danger">Cerrar Sesión</button>
                                </form>
                            </div>
                            </div>
                        </div>
                        <!--end user image section-->

    
        <div class="menu_admin" style="width: 60%;">
            <div class="menu_bar">
                <a href="#" class="bt-menu"><span class="icon-home"></span> Menu</a>
            </div>
            <nav>
                <ul>
                


                    <li><a href="http://localhost:8080/bupalweb"><span target="formularios" class="icon-pencil"></span> Oficio</a></li>
                    <li><a href="#"><span class="icon-calendar"></span> Auditorio</a></li>
                    <!--<li><a href="#"></a></li>
                    <li><a href="#"></a></li>
                    <li><a href="#"></a></li>-->
                </ul>
            </nav>
                <!-- end side-menu -->


        </div>

            <!-- end sidebar-collapse -->

  <div class="principal" style="width: 0px; height: 0px;">
            
            <iframe src="http://localhost:8080/reservapp/" style="width: 90%; height: 1000px;" name="formularios"></iframe>
        </div>
    


              
<iframe src="http://localhost:8080/reservapp/" style="width: 90%; height: 800px; position: relative;" name="formularios"></iframe>
              </div>



    </div>
    <!-- end wrapper -->







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>