@extends('layouts.app')

@section('content')

	<!-- Start WOWSlider.com HEAD section --> <!-- add to the <head> of your page
	<link rel="stylesheet" type="text/css" href="../slidermodulos/engine1/style.css" />
	<script type="text/javascript" src="../slidermodulos/engine1/jquery.js"></script>
	<!-- End WOWSlider.com HEAD section -->


<!-- Start WOWSlider.com HEAD section --> <!-- add to the <head> of your page 
	<link rel="stylesheet" type="text/css" href="public/../slidermodulos/engine1/style.css" />
	<script type="text/javascript" src="public/../slidermodulos/engine1/jquery.js"></script>
	<!-- End WOWSlider.com HEAD section -->

		<!-- Start WOWSlider.com HEAD section --> <!-- add to the <head> of your page -->
	<link rel="stylesheet" type="text/css" href="/slider_principal/engine1/style.css" />
	<script type="text/javascript" src="/slider_principal/engine1/jquery.js"></script>
	<!-- End WOWSlider.com HEAD section -->

  <!--  wrapper -->
  <div class="row" style=" margin-top: 12%;">
  	<div class="col-md-3" style="margin-left: -10%; float: left; visibility: ; border-style: solid; border-color: blue; z-index: -1;">
  	<!--<input type="submit" class="btn btn-primary" name="">-->
  		<!-- Start WOWSlider.com BODY section --> <!-- add to the <body> of your page -->

  			<!--<div id="comslider_in_point_1567805"></div><script type="text/javascript">var oCOMScript1567805=document.createElement('script');oCOMScript1567805.src="https://commondatastorage.googleapis.com/comslider/target/users/1524534008x1cc8d3acae3ceaaf21042767cc5771c0/comslider.js?timestamp=1524589274&ct="+Date.now();oCOMScript1567805.type='text/javascript';document.getElementsByTagName("head").item(0).appendChild(oCOMScript1567805);</script>

	<div id="wowslider-container1">
	<div class="ws_images"><ul>
		<li><img src="../slidermodulos/data1/images/29472063_580616888956939_25591712957071360_n.png" alt="29472063_580616888956939_25591712957071360_n" title="29472063_580616888956939_25591712957071360_n" id="wows1_0"/></li>
		<li><img src="../slidermodulos/data1/images/29497024_580616915623603_5522091868248080384_n.png" alt="29497024_580616915623603_5522091868248080384_n" title="29497024_580616915623603_5522091868248080384_n" id="wows1_1"/></li>
		<li><img src="../slidermodulos/data1/images/29388911_580616922290269_6843070181812469760_n.png" alt="29388911_580616922290269_6843070181812469760_n" title="29388911_580616922290269_6843070181812469760_n" id="wows1_2"/></li>
		<li><img src="../slidermodulos/data1/images/29425948_580616955623599_5435791402447405056_n.png" alt="29425948_580616955623599_5435791402447405056_n" title="29425948_580616955623599_5435791402447405056_n" id="wows1_3"/></li>
		<li><img src="../slidermodulos/data1/images/29472792_580616992290262_6697724803433889792_n.png" alt="29472792_580616992290262_6697724803433889792_n" title="29472792_580616992290262_6697724803433889792_n" id="wows1_4"/></li>
		<li><img src="../slidermodulos/data1/images/29511649_580617018956926_8119314130361384960_n.png" alt="29511649_580617018956926_8119314130361384960_n" title="29511649_580617018956926_8119314130361384960_n" id="wows1_5"/></li>
		<li><img src="../slidermodulos/data1/images/29426166_580617038956924_3939807525351718912_n.png" alt="29426166_580617038956924_3939807525351718912_n" title="29426166_580617038956924_3939807525351718912_n" id="wows1_6"/></li>
		<li><img src="../slidermodulos/data1/images/29425186_580617072290254_3270598105342410752_n.png" alt="29425186_580617072290254_3270598105342410752_n" title="29425186_580617072290254_3270598105342410752_n" id="wows1_7"/></li>
		<li><img src="../slidermodulos/data1/images/29388775_580617102290251_4540866225374232576_n.png" alt="29388775_580617102290251_4540866225374232576_n" title="29388775_580617102290251_4540866225374232576_n" id="wows1_8"/></li>
		<li><img src="../slidermodulos/data1/images/29432248_580617128956915_2845220008861106176_n.png" alt="29432248_580617128956915_2845220008861106176_n" title="29432248_580617128956915_2845220008861106176_n" id="wows1_9"/></li>
		<li><img src="../slidermodulos/data1/images/29432252_580617158956912_6623017274703872000_n.png" alt="29432252_580617158956912_6623017274703872000_n" title="29432252_580617158956912_6623017274703872000_n" id="wows1_10"/></li>
		<li><img src="../slidermodulos/data1/images/29496552_580617175623577_3385948694846111744_n.png" alt="29496552_580617175623577_3385948694846111744_n" title="29496552_580617175623577_3385948694846111744_n" id="wows1_11"/></li>
		<li><img src="../slidermodulos/data1/images/29425529_580617228956905_7017899192123129856_n.png" alt="29425529_580617228956905_7017899192123129856_n" title="29425529_580617228956905_7017899192123129856_n" id="wows1_12"/></li>
		<li><img src="../slidermodulos/data1/images/29425063_580617242290237_4447956934481412096_n.png" alt="29425063_580617242290237_4447956934481412096_n" title="29425063_580617242290237_4447956934481412096_n" id="wows1_13"/></li>
		<li><img src="../slidermodulos/data1/images/29389186_580617278956900_5379133448009023488_n.png" alt="29389186_580617278956900_5379133448009023488_n" title="29389186_580617278956900_5379133448009023488_n" id="wows1_14"/></li>
		<li><img src="../slidermodulos/data1/images/29496812_581240468894581_3753787964866428928_n.png" alt="29496812_581240468894581_3753787964866428928_n" title="29496812_581240468894581_3753787964866428928_n" id="wows1_15"/></li>
		<li><img src="../slidermodulos/data1/images/29496076_581240485561246_6106361270527590400_n.png" alt="29496076_581240485561246_6106361270527590400_n" title="29496076_581240485561246_6106361270527590400_n" id="wows1_16"/></li>
		<li><img src="../slidermodulos/data1/images/29572330_581240495561245_680195641409798144_n.png" alt="29572330_581240495561245_680195641409798144_n" title="29572330_581240495561245_680195641409798144_n" id="wows1_17"/></li>
		<li><img src="../slidermodulos/data1/images/29472954_581240525561242_3212567642564984832_n.png" alt="29472954_581240525561242_3212567642564984832_n" title="29472954_581240525561242_3212567642564984832_n" id="wows1_18"/></li>
		<li><img src="../slidermodulos/data1/images/29468978_581240572227904_6390527967667159040_n.png" alt="29468978_581240572227904_6390527967667159040_n" title="29468978_581240572227904_6390527967667159040_n" id="wows1_19"/></li>
		<li><a href="http://wowslider.net"><img src="../slidermodulos/data1/images/29573017_581240585561236_6317225919740116992_n.png" alt="html slider" title="29573017_581240585561236_6317225919740116992_n" id="wows1_20"/></a></li>
		<li><img src="../slidermodulos/data1/images/29541203_581240622227899_2227212130937995264_n.png" alt="29541203_581240622227899_2227212130937995264_n" title="29541203_581240622227899_2227212130937995264_n" id="wows1_21"/></li>
	</ul></div>

	</div>	-->


	<script>
    /**
    * Array con las imagenes que se iran mostrando en la web
    */
    var imagenes=new Array(
        'http://localhost:8000/slidermodulos/data1/images/29388775_580617102290251_4540866225374232576_n.png',
        'http://localhost:8000/slidermodulos/data1/images/29388911_580616922290269_6843070181812469760_n.png',
        'http://localhost:8000/slidermodulos/data1/images/29389186_580617278956900_5379133448009023488_n.png',
        'http://localhost:8000/slidermodulos/data1/images/29425063_580617242290237_4447956934481412096_n.png',
        'http://localhost:8000/slidermodulos/data1/images/29425186_580617072290254_3270598105342410752_n.png',
        'http://localhost:8000/slidermodulos/data1/images/29425529_580617228956905_7017899192123129856_n.png'
        
    );


 
    /**
    * Funcion para cambiar la imagen
    */
    function rotarImagenes()
    {
        // obtenemos un numero aleatorio entre 0 y la cantidad de imagenes que hay
        var index=Math.floor((Math.random()*imagenes.length));
 
        // cambiamos la imagen
        document.getElementById("imagen").src=imagenes[index];
    }
 
    /**
    * Función que se ejecuta una vez cargada la página
    */
    onload=function()
    {
        // Cargamos una imagen aleatoria
        rotarImagenes();
 
        // Indicamos que cada 5 segundos cambie la imagen
        setInterval(rotarImagenes,10000);
    }


</script>


     <!-- <div id="imagendiv">
    <img src="" id="imagen">

    <!--<video src="" id="imagen" autoplay="true" muted></video>

      </div>-->


  	</div>
  <div class="" style="">
    <!--<iframe src="/slider_principal/index.html" style="width: 700px; height: 600px; overflow: hidden;"></iframe>-->
    <div class="embed" style=" margin-left: 15%;  width: 1000px; height: 500px; position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden;">
<!--<iframe src="/comslider_1563449/comslider1563449.html" style="width: 1000px; height: 500px; position: absolute; top: 0; left: 0; width: 100%; height: 100%;"></iframe>-->







	
	<!-- Start WOWSlider.com BODY section --> <!-- add to the <body> of your page -->
	<div id="wowslider-container1" style="">
	<div class="ws_images"><ul>
		<li><img src="/slider_principal/data1/images/dsc_0057.jpg" alt="DSC_0057" title="DSC_0057" id="wows1_0"/></li>
		<li><img src="/slider_principal/data1/images/12p.png" alt="12p" title="12p" id="wows1_1"/></li>
		<li><img src="/slider_principal/data1/images/dsc_7374.jpg" alt="DSC_7374" title="DSC_7374" id="wows1_2"/></li>
		<li><img src="/slider_principal/data1/images/4p.png" alt="4p" title="4p" id="wows1_3"/></li>
		<li><img src="/slider_principal/data1/images/dsc_0153.jpg" alt="DSC_0153" title="DSC_0153" id="wows1_4"/></li>
		<li><img src="/slider_principal/data1/images/9p.png" alt="9p" title="9p" id="wows1_5"/></li>
		<li><img src="/slider_principal/data1/images/dsc_5542.jpg" alt="DSC_5542" title="DSC_5542" id="wows1_6"/></li>
		<li><img src="/slider_principal/data1/images/6p.png" alt="6p" title="6p" id="wows1_7"/></li>
		<li><a href="http://wowslider.net"><img src="/slider_principal/data1/images/dsc_0264.jpg" alt="html5 slideshow" title="DSC_0264" id="wows1_8"/></a></li>
		<li><img src="/slider_principal/data1/images/conjunciones.png" alt="Conjunciones" title="Conjunciones" id="wows1_9"/></li>
	</ul></div>

	<div class="ws_shadow"></div>
	</div>	


</div>








<!--<div id="comslider_in_point_1563449"></div><script type="text/javascript">var oCOMScript1563449=document.createElement('script');oCOMScript1563449.src="https://commondatastorage.googleapis.com/comslider/target/users/1524032383x19dff88032a730b80bcd8414d24ff93b/comslider.js?timestamp=1524034752&ct="+Date.now();oCOMScript1563449.type='text/javascript';document.getElementsByTagName("head").item(0).appendChild(oCOMScript1563449);</script>-->




	
	<!-- Start WOWSlider.com BODY section --> <!-- add to the <body> of your page 
	<div id="wowslider-container1">
	<div class="ws_images"><ul>
		<li><img src="public/../slidermodulos/data1/images/1p.png" alt="" title="" id="wows1_0"/></li>
		<li><img src="public/../slidermodulos/data1/images/2p.png" alt="" title="" id="wows1_1"/></li>
		<li><img src="public/../slidermodulos/data1/images/3p.png" alt="" title="" id="wows1_2"/></li>
		<li><img src="public/../slidermodulos/data1/images/4p.png" alt="" title="" id="wows1_3"/></li>
		<li><img src="public/../slidermodulos/data1/images/5p.png" alt="" title="" id="wows1_4"/></li>
		<li><img src="public/../slidermodulos/data1/images/6p.png" alt="" title="" id="wows1_5"/></li>
		<li><img src="public/../slidermodulos/data1/images/7p.png" alt="" title="" id="wows1_6"/></li>
		<li><a href="http://wowslider.net"><img src="public/../slidermodulos/data1/images/8p.png" alt="image slider" title="" id="wows1_7"/></a></li>
		<li><img src="public/../slidermodulos/data1/images/9p.png" alt="" title="" id="wows1_8"/></li>
	</ul></div>

	</div>	
	<script type="text/javascript" src="public/../slidermodulos/engine1/wowslider.js"></script>
	<script type="text/javascript" src="public/../slidermodulos/engine1/script.js"></script>
	<!-- End WOWSlider.com BODY section -->



	<!--<div id="comslider_in_point_1563449"></div>
<script type="text/javascript">
var oCOMScript1563449=document.createElement('script');
oCOMScript1563449.src="public/comslider1563449/comsliderd.js?timestamp=1524035457";
oCOMScript1563449.type='text/javascript';
document.getElementsByTagName("head").item(0).appendChild(oCOMScript1563449);
</script>-->

</div>

	</div>


@endsection
