@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="" style="text-align: center;">
                    <?php
                        echo "Fecha: " . date("d") . "/" . date("m") . "/" . date("Y") . "<br>" . "Semana " . date("W");

                        echo "<h3>Gestión Diaria </h3>";
                    ?>
                    
                </div>

                <div class="">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif


                </div>
                
            </div>

        </div>
    </div>

    <div class="row" style="text-align: center; border-style: solid; border-color: black;">

        <section class="content">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="pull-left"><h3>Sistemas</h3></div>
                        <div class="pull-right">
                            <div class="btn-group">
                                <a href="{{ route('registrar.create') }}" class="btn btn-info">Registrar Actividad</a>
                            </div>
                        </div>
                        <div class="table-container">
                            <table id="entidad_sistemas" class="table table-bordred table-striped">
                                <iframe src="<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSeyvmJXgTT2RGSwMKneKz1xZ9DV-UOMxMVVWZ9xxb0zII8g3A/viewform" width="700" height="520" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>"></iframe>
                                </tbody>
                            </table>
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>

    </div>


    <div class="row" style="border-style: none; border-color: blue;">

        <div>
          <a class="buy-with-crypto"
             href="https://commerce.coinbase.com/checkout/5ce185e5-4dff-4886-9384-ed3a079e00d7">
            <span>Buy with Crypto</span>
          </a>
          <script src="https://commerce.coinbase.com/v1/checkout.js">
          </script>
        </div>

    </div>


</div>
@endsection