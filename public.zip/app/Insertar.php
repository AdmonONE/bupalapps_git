<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Insertar extends Model
{
    protected $table = 'registros';
}